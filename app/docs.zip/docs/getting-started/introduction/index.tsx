'use client'
import type { FC } from 'react'
import IntroductionContent from './Introduction.mdx'

const Introduction: FC = () => <IntroductionContent />

export default Introduction
