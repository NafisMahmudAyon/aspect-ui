'use client'
import type { FC } from 'react'
import TypographyContent from './Typography.mdx'

const Typography: FC = () => <TypographyContent />

export default Typography
