'use client'
import type { FC } from 'react'
import ColorsContent from './Colors.mdx'

const Colors: FC = () => <ColorsContent />

export default Colors
