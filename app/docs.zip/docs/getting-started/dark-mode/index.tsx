'use client'
import type { FC } from 'react'
import DarkModeContent from './DarkMode.mdx'

const DarkMode: FC = () => <DarkModeContent />

export default DarkMode
